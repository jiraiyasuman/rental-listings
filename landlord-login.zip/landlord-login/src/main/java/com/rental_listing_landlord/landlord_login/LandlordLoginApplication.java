package com.rental_listing_landlord.landlord_login;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LandlordLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(LandlordLoginApplication.class, args);
	}

}
