package com.rental_listing_landlord.landlord_post;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LandlordPostApplicationTests {

	@Test
	void contextLoads() {
	}

}
