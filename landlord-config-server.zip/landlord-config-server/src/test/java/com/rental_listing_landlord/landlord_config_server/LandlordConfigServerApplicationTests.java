package com.rental_listing_landlord.landlord_config_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LandlordConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
