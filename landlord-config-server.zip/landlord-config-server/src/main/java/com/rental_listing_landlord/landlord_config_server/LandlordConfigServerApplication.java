package com.rental_listing_landlord.landlord_config_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LandlordConfigServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(LandlordConfigServerApplication.class, args);
	}

}
