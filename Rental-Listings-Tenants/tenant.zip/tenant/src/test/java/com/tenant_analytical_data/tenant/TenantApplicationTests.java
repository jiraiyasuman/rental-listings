package com.tenant_analytical_data.tenant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TenantApplicationTests {

	@Test
	void contextLoads() {
	}

}
