package com.tenant_payment_gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TenantPaymentGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(TenantPaymentGatewayApplication.class, args);
	}

}
