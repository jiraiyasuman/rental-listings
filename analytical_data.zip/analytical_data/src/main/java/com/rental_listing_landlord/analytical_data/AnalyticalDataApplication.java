package com.rental_listing_landlord.analytical_data;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnalyticalDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnalyticalDataApplication.class, args);
	}

}
