package com.rental_listing_landlord.landlord_api_gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LandlordApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
