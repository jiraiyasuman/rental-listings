package com.rental_listing_landlord.landlord;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LandlordApplicationTests {

	@Test
	void contextLoads() {
	}

}
